function setupsinstim
% SETUPSINSTIM  Set MATLAB path for SinStim.
%    Change current directory to the "SinStim" folder and run this command
%    to intall SinStim. You are supposed to have installed PsychTooBox,
%    BenTools and GraphicsLab before.


%% Check if GraphicsLab & BenTools are installed
if isempty(which('setupglab'))
    disp(['GraphicsLab is not installed.' 10 ...
        'Please, install first GraphicsLab, then re-run setupsinstim.'])
end

%% Set path
disp('Setting MATLAB path for SinStim...')
w = which('setupsinstim');
s = find(w == filesep);
root = w(1:s(end));
addpath(fullfile(root,'Program'));
savepath;
disp('Done.')