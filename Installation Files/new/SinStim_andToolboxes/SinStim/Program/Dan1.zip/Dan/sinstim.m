
function sinstim(varargin)
% SinStim   Sinusoidal stimulation -- EEG Experimental Program.

sinstim1p8p9dan2







(varargin{:});