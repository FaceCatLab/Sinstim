function [chnumrand, charSet]= randChar2(chnum1,chnum2,repCy,numCy,numOdd)
%repCy: target in how many cycles?
%numCy: how many cycles?
%numOdd: how many kinds of oddballs?

chnum1rep = repmat(chnum1,1,numOdd*(repCy-1));
chnumsettmp = [chnum1rep, chnum2];
repFactor = ceil(numCy/size(chnumsettmp, 2));
chnumset = repmat(chnumsettmp,1,repFactor);
chnumrand = shuffle(chnumset);

charSet = char(chnumrand);
end
