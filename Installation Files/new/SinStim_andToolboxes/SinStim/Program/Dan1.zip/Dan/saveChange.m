
function saveChange(indColorA,indColorB,indShapeA,indShapeB,directory)
minIndex=min([min(indColorA) min(indColorB)]);
maxIndex=max([max(indColorA) max(indColorB)]);

try minIndex==min([min(indShapeA) min(indShapeB)]);
catch display('Problem with the procedure');
end

try maxIndex=max([max(indShapeA) max(indShapeB)]);
catch display('Problem with the procedure');
end

% Indices.Color.A=indColorA;
% Indices.Color.B=indColorB;
% Indices.Shape.A=indShapeA;
% Indices.Shape.B=indShapeB;

ColorAFrames=vectorRazor(indColorA);
ColorBFrames=vectorRazor(indColorB);
ShapeAFrames=vectorRazor(indShapeA);
ShapeBFrames=vectorRazor(indShapeB);

q=now;
a=datestr(q);
a=[directory '/' [a(1:14)] [a(16:17)] '.mat'];
display(a);
save(a, 'ColorAFrames', 'ColorBFrames', 'ShapeAFrames', 'ShapeBFrames')




