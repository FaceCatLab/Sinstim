function [vector1,vector2,times1,times2]=arrangeInput(blockDuration,graceTimeStart,graceTimeEnd,freq1,freq2,primaryEvent,secondaryEvent,refractoryPeriod,numberOfChanges,code1,code2)

[vector1 times1]=arrangeVector(blockDuration,graceTimeStart,graceTimeEnd,freq1,primaryEvent,secondaryEvent,refractoryPeriod,numberOfChanges,code1);
vector1=vector1(3:end);
times1=times1(3:end);

[vector2 times2]=arrangeVector(blockDuration,graceTimeStart,graceTimeEnd,freq2,primaryEvent,secondaryEvent,refractoryPeriod,numberOfChanges,code2);


% [firstfreq secondfreq dan adriano]=arrangeInput(74,4,4,5.88,7.14,'1','a',1.5,6,'0','5')