function [vector]=vectorRazor(vec)
vector=vec(1);
n=2;
for i=2:length(vec)
    if vec(i-1)~=vec(i)-1
        vector(n)=vec(i);
        n=n+1;
    end
end
  