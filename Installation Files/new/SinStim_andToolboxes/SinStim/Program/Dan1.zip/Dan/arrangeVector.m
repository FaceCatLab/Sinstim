
function [vector indices]=arrangeVector(blockDuration,graceTimeStart,graceTimeEnd,freq,primaryEvent,secondaryEvent,refractoryPeriod,numberOfChanges,code)

% blockDuration=70; % in seconds
% graceTimeStart=4; % in seconds
% graceTimeEnd=4; % in seconds
% freq=5.8; % in Hertz
% primaryEvent='1';
% secondaryEvent='a';
% refractoryPeriod=1.5;  % in seconds
% numberOfChanges=10;
% code='5';


vectorLength=floor(blockDuration*freq);
vector=repmat(primaryEvent,1,vectorLength);
indices=repmat('0',1,vectorLength);


averageRefractoryLength=floor(refractoryPeriod*freq);
averageLengthOfChange=floor((blockDuration-graceTimeStart-graceTimeEnd)*freq/numberOfChanges)-averageRefractoryLength;

lowlim=averageRefractoryLength;
lowlim
highlim=averageLengthOfChange+averageRefractoryLength;
highlim
index=floor(graceTimeStart*freq);

n=0;


while n<numberOfChanges
    advance=round(random('unif',lowlim,highlim));
    vector(index+advance)=secondaryEvent;
    indices(index+advance)=code;
    index=index+advance+averageRefractoryLength;
    n=n+1;
end
