ASIO enabled version of portaudio_x86.dll:
==========================================

The included portaudio_x86.dll for the Microsoft Windows
operating system is an extended version of the "PortAudio
Portable Real-Time Audio Library" which is included in
the Psychtoolbox/PsychSound/ subfolder of Psychtoolbox-3.

PortAudio is Copyright (c) 1999-2006 Ross Bencina and Phil Burk.

This DLL is copyright Mario Kleiner. See the LICENSE.txt file
for exact licensing conditions.

This binary DLL contains compiled-in support for the
ASIO Interface Technology by Steinberg Media Technologies GmbH,
by use of the Steinberg ASIO SDK, Version 2.2.

ASIO is a trademark and software of Steinberg Media Technologies GmbH.

This extended DLL allows the Psychtoolbox sound driver PsychPortAudio
to access so called "ASIO capable" sound cards under Microsoft
Windows via their ASIO interface, thereby providing much more
accurate and robust sound onset timing and sound capture onset timing,
as well as precise sound timestamping, lower absolute sound onset
latency, multi-channel sound capture/playback capabilities and
a host of other useful features.


SYSTEM REQUIREMENTS:
====================

This DLL is only needed on Microsoft Windows, not if you're
using Apple MacOS/X or GNU/Linux. PsychPortAudio has already
built-in support for those operating systems.

You will need a soundcard with ASIO support to take
advantage of this DLL. Preferably you will own a
soundcard with native ASIO support and have the latest
ASIO capable device drivers for that card installed on
your machine.

If you don't have an ASIO capable soundcard you can
try to download and install ASIO4ALL (http://www.asio4all.com/),
a free "Universal ASIO Driver For WDM Audio". ASIO4ALL
emulates an ASIO interface on top of the standard WDM audio
drivers of cheaper sound cards. It tries its best to replicate
correct ASIO behaviour, but given that this emulation depends
crucially on the underlying WDM drivers and hardware, which aren't
designed for high quality time accurate sound handling, the
quality of this emulation may vary greatly. Please consult
the webpage of ASIO4ALL for listings of sound cards that work
well, and for troubleshooting and tuning tips for specific
sound cards. Good luck if you take this route.


INSTALLATION:
=============

Simply copy the provided psychportaudio_x86.dll into the
Psychtoolbox main folder and restart Matlab.

If you type InitializePsychSound on the Matlab prompt,
the function will detect and load the new dll and show
something like the following text to confirm proper
installation of the DLL:

"Detected an ASIO enhanced PortAudio driver. Good!"

You should also see some text like:
"Found at least one ASIO enabled soundcard in your system."

If you don't see that text, then the DLL was properly installed,
but something is wrong with the setup of your soundcard and
therefore ASIO support can't be enabled. Consult the soundcards
user manual for troubleshooting tips.


USAGE:
======

To use ASIO support in your scripts, you'll need to include
a call to InitializePsychSound before the first call to
PsychPortAudio.

In the PsychPortAudio('Open',...); call you should open the
device in low latency mode, that is, the optional
'reqlatencyclass' parameter should be set to 1 or higher, not
to its default setting of zero. A setting of zero would choose
the default audio output device of your system for sound output,
which may not be the ASIO interface. A setting of 1 will strive
to get access to the ASIO sound interface and configure the
driver and sound system for low-latency and high timing precision.


TUNING TIPS:
============

* Most modern sound cards only support a few selected sample rates
in hardware. Usually these are 48000 Hz, maybe 44100 Hz, maybe
96000 Hz, maybe 192000 Hz. Choosing a different sample rate for
the optional 'freq' parameter in PsychPortAudio('Open',...) may
require the driver to do extra work for software-based sample rate
conversion. This may degrade timing accuracy, increase latency and
possibly degrade the quality of sound.

* The 'reqlatencyclass' parameter, depending on its value, selects
a couple of preset settings for the optional parameters 'freq',
'buffersize' and 'suggestedLatency'. Higher values for 'reqlatencyclass'
select "more aggressive" default settings for the other parameters.

More aggressive means: Allowing for lower absolute latencies in
sound playback, capture and feedback, but also putting more stress
onto the sound hardware and operating system, with the possible
consequence of sound dropouts, glitches and other audible artifacts,
depending on the quality of your soundcard and operating system.

Most studies in sound perception, audio-visual integration, etc.,
do not need very low sound onset latency, but only precise sound
onset timing and precise sound onset timestamps. Precise timing
can already be achieved at a 'reqlatencyclass' setting of 1.

Only few studies really need low absolute latency, e.g.,
because sound onset must be triggered with low latency by some
external event like a subjects response, or some external trigger
signal, or if you want to create some audio feedback loop. In that
case you can try the more aggressive 'reqlatencyclass' settings of
2, 3 or 4.

* Sometimes the presets of PsychPortAudio are too much for lower
end hardware and you'll experience sound glitches. In that case
you should play with the optional 'suggestedLatency' parameter in
PsychPortAudio('Open',...);
The parameter requests a specific latency (in seconds). If you hear
glitches, then likely our default preset of 0.005 secs (== 5 msecs)
is too stressful for the hardware. Try with a setting of 0.010 secs,
or even 0.015 or 0.020 secs and see if your hardware behaves better.

* Some hardware doesn't allow PsychPortAudio to change latency
related hardware settings. In that case, consult the documentation
of your soundcard for a way to change these settings in some
soundcard settings dialog or setup application. If you find some
setting called "ASIO buffersize" or "Samplebuffer size" or something
similar, then you've likely found what you need. Higher samplebuffer
sizes mean higher latencies, but less stress to the system. Lower
settings mean lower latencies but more stress.

* If you perform timing sensitive studies you absolutely must
use external measurement equipment at least once to validate
the correct behaviour of your setup! There is no way for us
to check and verify correct timing in software if there are
sound driver bugs or hardware bugs!

One way of checking is by use of the PsychPortAudioTimingTest
script. It synchronously emits a beep-sound through your soundcard
and flashes a white image on your display. You can use a microphone
to pick up the beep tone, a photo-diode to pick up the flash of white
light, and a scope to compare the signal traces of the photo-diode
and the microphone in order to verify synchronous sound- and
display onset. Make sure to use a CRT display, not a flat panel,
otherwise the measurement will be distorted by visual latency!


EXAMPLES:
=========

* BasicSoundOutputDemo demonstrates sound playback in standard mode,
  ie., not in low-latency / high timing precision mode.

* BasicSoundInputDemo demonstrates sound capture.

* PsychPortAudioTimingTest demonstrates exact, high precision timing
  sound onset as well as low-latency sound output.

* BasicSoundFeedbackDemo demonstrates implementation of a delayed
  sound feedback loop which captures sound from a microphone and
  plays it back over the speakers with controllable delay.


WELL WORKING SOUND HARDWARE:
============================

PsychPortAudios timing and functionality in conjunction with ASIO
under Microsoft Windows 2000 and XP has been verified by a number of people
on different setups. Among others, the following sound cards are known
to be well-behaved wrt. latency and sound onset timing:

* M-Audio Delta 1010-LT multichannel card: Provides excellent timing and latency.

* Creative Labs Audigy 4, Creative Sound Blaster X-Fi : Works well. In general,
  most recent Creative labs cards seem to be well behaved.

* "RME Hammerfall" and "RME FireFace".

* MOTU 828mkII.


MORE INFORMATION:
=================

For more information, check the Psychtoolbox Wiki section about PsychPortAudio:

<http://psychtoolbox.org/wikka.php?wakka=PsychPortAudio>

For specific questions, write to the Psychtoolbox user forum.


Good luck,
-mario
